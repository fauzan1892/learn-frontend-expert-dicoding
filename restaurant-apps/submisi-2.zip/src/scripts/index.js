import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';

import downMenu from './downMenu.js';
import main from './main.js';

downMenu();
main();